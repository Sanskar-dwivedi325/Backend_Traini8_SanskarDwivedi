package com.example.Backend_Traini8_SanskarDwivedi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendTraini8SanskarDwivediApplicationTests {

	@Test
	void contextLoads() {
	}

}
