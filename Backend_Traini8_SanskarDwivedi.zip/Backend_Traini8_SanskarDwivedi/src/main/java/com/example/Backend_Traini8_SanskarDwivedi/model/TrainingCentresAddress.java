package com.example.Backend_Traini8_SanskarDwivedi.model;

import jakarta.persistence.*;

@Entity
public class TrainingCentresAddress {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int adressID;
    private String Fulladdress;
    private String City;
    private String state;
    private String pincode;


    public int getAdressID() {
        return adressID;
    }

    public void setAdressID(int adressID) {
        this.adressID = adressID;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public String getFulladdress() {
        return Fulladdress;
    }

    public void setFulladdress(String fulladdress) {
        Fulladdress = fulladdress;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }
}
