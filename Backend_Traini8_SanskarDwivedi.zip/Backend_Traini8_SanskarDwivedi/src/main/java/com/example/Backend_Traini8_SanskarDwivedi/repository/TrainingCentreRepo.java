package com.example.Backend_Traini8_SanskarDwivedi.repository;

import com.example.Backend_Traini8_SanskarDwivedi.model.TrainingCentre;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TrainingCentreRepo extends JpaRepository<TrainingCentre, Integer> {

}
