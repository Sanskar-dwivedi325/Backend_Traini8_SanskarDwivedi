package com.example.Backend_Traini8_SanskarDwivedi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendTraini8SanskarDwivediApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendTraini8SanskarDwivediApplication.class, args);
	}

}
