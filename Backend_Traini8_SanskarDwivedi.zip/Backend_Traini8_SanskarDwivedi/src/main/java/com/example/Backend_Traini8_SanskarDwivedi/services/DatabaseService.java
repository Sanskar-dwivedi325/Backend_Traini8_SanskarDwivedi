package com.example.Backend_Traini8_SanskarDwivedi.services;

import com.example.Backend_Traini8_SanskarDwivedi.model.TrainingCentre;
import com.example.Backend_Traini8_SanskarDwivedi.repository.TrainingCentreRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DatabaseService {

    @Autowired
    TrainingCentreRepo trainingCentreRepo;


    //saving new Centres

    public TrainingCentre createTrainingCentre(TrainingCentre trainingCentre){
        TrainingCentre inserted;
        try {
            inserted = trainingCentreRepo.save(trainingCentre);
            return inserted;
        }

        catch (Exception e){
           return null;
        }


    }


    //getting all centers

    public List<TrainingCentre> getAllTrainingCentre(){
        return trainingCentreRepo.findAll();
    }
}
