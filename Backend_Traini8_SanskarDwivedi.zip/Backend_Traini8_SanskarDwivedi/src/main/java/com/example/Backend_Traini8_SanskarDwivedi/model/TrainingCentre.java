package com.example.Backend_Traini8_SanskarDwivedi.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import org.hibernate.annotations.CreationTimestamp;
import java.util.List;

@Entity
public class TrainingCentre {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer TrainingCentreId;

    @NotNull(message = "CentreName cannot be null")
    @NotBlank(message = "CentreName cannot be blank")
    @Size(max = 40,message = "CentreName should be of Maximum 40 characters")
    private String centreName;


    @Column(unique = true)
    @Pattern(regexp = "^[a-zA-Z0-9]{12}$",message = "centreCode must be of 12 alphanumeric characters")
    private String centreCode;

    @OneToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
    @JoinColumn(name="TrainingCentresAddress_adressid")
    @NotNull(message = "address should not be null")
    private TrainingCentresAddress address;


    private int studentCapacity;


    @ElementCollection
    private List<String> coursesOffered;

    @CreationTimestamp
    private String createdOn;

    @Email(message = "write email in proper format")
    private String contactEmail;

    @Pattern(regexp = "^\\+?[0-9]{10,15}$",message = "invalid phone number")
    private String contactPhone;


    public Integer getTrainingCentreId() {
        return TrainingCentreId;
    }

    public void setTrainingCentreId(Integer trainingCentreId) {
        TrainingCentreId = trainingCentreId;
    }

    public String getCentreName() {
        return centreName;
    }

    public void setCentreName(String centreName) {
        this.centreName = centreName;
    }

    public String getCentreCode() {
        return centreCode;
    }

    public void setCentreCode(String centreCode) {
        this.centreCode = centreCode;
    }

    public TrainingCentresAddress getAddress() {
        return address;
    }

    public void setAddress(TrainingCentresAddress address) {
        this.address = address;
    }

    public int getStudentCapacity() {
        return studentCapacity;
    }

    public void setStudentCapacity(int studentCapacity) {
        this.studentCapacity = studentCapacity;
    }

    public List<String> getCoursesOffered() {
        return coursesOffered;
    }

    public void setCoursesOffered(List<String> coursesOffered) {
        this.coursesOffered = coursesOffered;
    }

    public String getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }



}
