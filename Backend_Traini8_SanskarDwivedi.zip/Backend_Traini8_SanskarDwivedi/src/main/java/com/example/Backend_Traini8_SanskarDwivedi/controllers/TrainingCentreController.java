package com.example.Backend_Traini8_SanskarDwivedi.controllers;

import com.example.Backend_Traini8_SanskarDwivedi.model.TrainingCentre;
import com.example.Backend_Traini8_SanskarDwivedi.model.TrainingCentresAddress;
import com.example.Backend_Traini8_SanskarDwivedi.services.DatabaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import jakarta.validation.Valid;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;

@RestController
public class TrainingCentreController {

     @Autowired
     DatabaseService databaseService;

     /* Post request for adding new training center
    localhost:8080/save      */
    @PostMapping(path = "/save")
    public ResponseEntity<?> saveClient(@Valid @RequestBody TrainingCentre trainingCentre, BindingResult bindingResult) {

        //if their is error then show message
        if (bindingResult.hasErrors()) {
           Map<String, String> errors = new HashMap<>();
           bindingResult.getFieldErrors().forEach(error -> {errors.put(error.getField(), error.getDefaultMessage());});
           return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);

        }


           TrainingCentre inserted=databaseService.createTrainingCentre(trainingCentre);
        if(inserted!=null) {
            return new ResponseEntity<>(inserted, HttpStatus.OK); //if no error return created object
        } else {
            Map<String, String> response = new HashMap<>();
            response.put("message", "Something went wrong");
            response.put("Common Issue","Centre Code is already exist");

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);//if their is any internal error show null
        }
    }

    //localhost:8080/getTrainingCentre
    @GetMapping(path = "/getTrainingCentre")
    public ResponseEntity<List<TrainingCentre>> getClients() {
        return new ResponseEntity<>(databaseService.getAllTrainingCentre(), HttpStatus.OK);//returning array of all objects in json format
    }
}
